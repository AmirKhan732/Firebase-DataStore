export const CLOUDINARY_CLOUD_NAME = "djlx0ia0o";  
export const CLOUDINARY_UPLOAD_PRESET = "unsigned_items";
export const CLOUDINARY_UPLOAD_URL =
  `https://api.cloudinary.com/v1_1/djlx0ia0o/image/upload`;