

import React from 'react';
import AppNavigator from './src/navigation';

export default function App() {
  return <AppNavigator />;
}